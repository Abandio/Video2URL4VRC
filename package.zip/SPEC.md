---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 30440220238514794ffd058fd5d1053831210110ccde1afb9518963a8ffa09ea14d6649502202447a18741a57de0f8fc93eaddc4f82b18e156abc5b0c4ed89b84a487598a6d3
    ReservedCode2: 304402200173e92f0a04acb4f842e5b02adbacb92c4d93e522613ae5cca9fee9819100000220143043c55fb100a40a6410748ec4afffb172d7954ef656738b1056b7de2bb446
---

# VRCHAT Video Stream Server - Technical Specification

## 1. Project Overview

### Project Name
VRCHAT Video Stream Server

### Core Functionality
A video hosting and streaming solution for Alibaba Cloud ECS that allows uploading 4K videos, automatic transcoding to VRCHAT-compatible format, and generating shareable URLs for video playback in VRCHAT environments.

### Target Users
- VRCHAT world developers
- Content creators who need to display videos in VRCHAT

---

## 2. Architecture

### System Components
```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  User Upload│ ──► │   Flask Backend  │ ──► │  Video Storage  │
│  (Web UI)   │     │  (Upload+Transcode)│     │  /data/videos   │
└─────────────┘     └──────────────────┘     └────────┬────────┘
                                                      │
                                                      ▼
                                            ┌─────────────────┐
                                            │  FFmpeg Transcode│
                                            │  (H.264/MP4)    │
                                            └────────┬────────┘
                                                      │
                                                      ▼
                                            ┌─────────────────┐
                                            │  Flask Stream    │
                                            │  (HTTP Streaming)│
                                            └────────┬────────┘
                                                      │
                                                      ▼
                                            ┌─────────────────┐
                                            │  VRCHAT Playback │
                                            │  (VideoPlayer)  │
                                            └─────────────────┘
```

### Tech Stack
- **Backend**: Python Flask
- **Video Processing**: FFmpeg (H.264 encoding)
- **Frontend**: Pure HTML/CSS/JavaScript
- **Streaming**: Flask with range request support

---

## 3. Features

### 3.1 Video Upload
- Web-based upload interface
- Drag and drop support
- File size limit: 10GB
- Supported formats: MP4, MKV, MOV, AVI, WEBM, WMV, FLV, M4V
- Real-time upload progress

### 3.2 Video Transcoding
- **Output Format**: H.264 MP4 (best VRCHAT compatibility)
- **Resolution**: Preserves original (up to 4K)
- **Bitrate Control**:
  - 4K (2160p): 30 Mbps, CRF 18
  - 1080p: 12 Mbps, CRF 18
  - Other: 8 Mbps, CRF 20
- **Audio**: AAC 256kbps stereo
- **Optimization**: +faststart flag for streaming

### 3.3 URL Generation
- **URL Format**: `http://SERVER_IP:5000/stream/VIDEO_ID.mp4`
- **One-click copy**: Copy URL to clipboard
- **Status display**: Processing/Ready

### 3.4 Video Management
- Video list with metadata
- Delete functionality
- Size and duration display

---

## 4. Video Optimization Strategy

### VRCHAT Compatibility
- VRCHAT VideoPlayer supports HTTP/HTTPS URLs
- Supports H.264, VP9, H.265 codecs
- H.264 recommended for best compatibility

### Transcode Parameters
```bash
# H.264 (Recommended for VRCHAT)
ffmpeg -i input.mkv \
  -c:v libx264 -preset medium -crf 18 \
  -maxrate 30M -bufsize 30M \
  -c:a aac -b:a 256k -ar 48000 -ac 2 \
  -movflags +faststart -pix_fmt yuv420p \
  output.mp4
```

### Quality vs Size Balance
| Resolution | Bitrate | File Size (est.) |
|------------|---------|-----------------|
| 4K (2160p) | 30 Mbps | ~1.5GB per 5min |
| 1080p | 12 Mbps | ~400MB per 5min |
| 720p | 8 Mbps | ~250MB per 5min |

---

## 5. Deployment Guide

### Prerequisites
- Alibaba Cloud ECS (Ubuntu/CentOS)
- Python 3.8+
- FFmpeg installed

### Installation Steps

```bash
# 1. Install FFmpeg
apt install ffmpeg

# 2. Install Python dependencies
pip install flask werkzeug

# 3. Upload files to ECS
# - app.py
# - templates/index.html
# - start.sh

# 4. Start service
chmod +x start.sh
./start.sh
```

### Configuration for Production

1. **Set firewall rules**: Open port 5000
2. **Configure data directory**: Edit WORKSPACE_DIR in start.sh
3. **Add HTTPS**: (Optional) Use nginx reverse proxy with SSL

---

## 6. API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Web upload interface |
| POST | `/api/upload` | Upload video file |
| GET | `/api/videos` | List all videos |
| GET | `/api/video/<id>/status` | Get processing status |
| DELETE | `/api/video/<id>` | Delete video |
| GET | `/stream/<filename>` | Stream video file |

---

## 7. File Structure
```
/workspace/
├── app.py              # Flask application
├── templates/
│   └── index.html      # Web interface
├── data/
│   ├── raw/            # Original uploads
│   ├── uploads/         # Metadata
│   └── videos/          # Transcoded videos
└── start.sh            # Startup script
```

---

## 8. VRCHAT Usage

### Getting Video URL
1. Open web interface at `http://YOUR_SERVER_IP:5000`
2. Upload video file
3. Wait for transcoding (status changes to "Ready")
4. Click "Copy" to copy video URL

### VRCHAT Setup
1. Open VRCHAT world with VideoPlayer support
2. Set VideoPlayer URL to the copied address
3. Video will stream and play in VRCHAT

### Tips for Best Performance
- Use wired internet connection for upload
- Videos under 5 minutes for best streaming
- Ensure server has adequate bandwidth

---

## 9. Troubleshooting

### Common Issues

**Upload fails**
- Check file size under 10GB
- Verify file format supported

**Transcoding fails**
- Check FFmpeg installed: `ffmpeg -version`
- Verify source file not corrupted

**VRCHAT can't play video**
- Verify URL accessible from internet
- Check firewall port 5000 open
- Ensure video format is H.264 MP4

---

## 10. Future Enhancements
- HTTPS support with SSL certificates
- User authentication for video access
- Video thumbnail generation
- Automatic cleanup of old videos
- Multiple quality presets
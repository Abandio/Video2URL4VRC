#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VRCHAT Video Stream Server
Flask Backend Application
- Web upload interface
- Video transcoding (H.264 optimized for VRCHAT)
- Video streaming server
"""

import os
import subprocess
import threading
import uuid
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, render_template, Response
from werkzeug.utils import secure_filename

app = Flask(__name__, template_folder='templates', static_folder='static')

# Configuration - Using workspace directory
WORKSPACE_DIR = '/workspace'
UPLOAD_FOLDER = f'{WORKSPACE_DIR}/data/uploads'
RAW_VIDEO_FOLDER = f'{WORKSPACE_DIR}/data/raw'
PROCESSED_VIDEO_FOLDER = f'{WORKSPACE_DIR}/data/videos'
ALLOWED_EXTENSIONS = {'mp4', 'mkv', 'mov', 'avi', 'webm', 'wmv', 'flv', 'm4v'}
MAX_CONTENT_LENGTH = 10 * 1024 * 1024 * 1024  # 10GB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RAW_VIDEO_FOLDER'] = RAW_VIDEO_FOLDER
app.config['PROCESSED_VIDEO_FOLDER'] = PROCESSED_VIDEO_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Ensure directories exist
for folder in [UPLOAD_FOLDER, RAW_VIDEO_FOLDER, PROCESSED_VIDEO_FOLDER]:
    os.makedirs(folder, exist_ok=True)


def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_video_duration(filepath):
    """Get video duration using ffprobe"""
    try:
        cmd = [
            'ffprobe', '-v', 'error', '-show_entries',
            'format=duration,size', '-of',
            'json', filepath
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        import json
        data = json.loads(result.stdout)
        return float(data['format']['duration']), int(data['format']['size'])
    except:
        return 0, 0


def transcode_video(input_path, output_path, video_id):
    """Transcode video to optimized format for VRCHAT"""
    try:
        # Get input video info for optimization
        probe_cmd = [
            'ffprobe', '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height,codec_name',
            '-of', 'json', input_path
        ]
        probe_result = subprocess.run(probe_cmd, capture_output=True, text=True)
        import json
        probe_data = json.loads(probe_result.stdout)

        # Determine output resolution and settings
        width = height = 0
        if probe_data.get('streams'):
            stream = probe_data['streams'][0]
            width = stream.get('width', 0)
            height = stream.get('height', 0)

        # Calculate target bitrate based on resolution
        if height >= 2160:  # 4K
            video_bitrate = '30M'
            crf = 18
            preset = 'slow'
        elif height >= 1080:  # 1080p
            video_bitrate = '12M'
            crf = 18
            preset = 'medium'
        else:
            video_bitrate = '8M'
            crf = 20
            preset = 'medium'

        # Build FFmpeg command for H.264 with optimization
        cmd = [
            'ffmpeg', '-y', '-i', input_path,
            '-c:v', 'libx264',
            '-preset', preset,
            '-crf', str(crf),
            '-maxrate', video_bitrate,
            '-bufsize', video_bitrate,
            '-c:a', 'aac',
            '-b:a', '256k',
            '-ar', '48000',
            '-ac', '2',
            '-movflags', '+faststart',
            '-pix_fmt', 'yuv420p',
        ]

        # Add scaling if needed (ensure even dimensions for H.264)
        if width and height:
            if width % 2 != 0 or height % 2 != 0:
                cmd.extend(['-vf', f'scale={width//2*2}:{height//2*2}'])

        cmd.append(output_path)

        # Execute transcoding
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            update_status(video_id, 'completed')
            return True
        else:
            update_status(video_id, 'failed')
            print(f"Transcode error: {stderr.decode()}")
            return False

    except Exception as e:
        update_status(video_id, 'failed')
        print(f"Transcode exception: {e}")
        return False


def update_status(video_id, status):
    """Update video processing status"""
    status_file = os.path.join(UPLOAD_FOLDER, f'{video_id}_status.txt')
    with open(status_file, 'w') as f:
        f.write(status)


def get_status(video_id):
    """Get video processing status"""
    status_file = os.path.join(UPLOAD_FOLDER, f'{video_id}_status.txt')
    if os.path.exists(status_file):
        with open(status_file, 'r') as f:
            return f.read().strip()
    return 'unknown'


@app.route('/')
def index():
    """Serve main upload page"""
    return render_template('index.html')


@app.route('/api/upload', methods=['POST'])
def upload_video():
    """Handle video upload"""
    if 'video' not in request.files:
        return jsonify({'error': 'No video file provided'}), 400

    file = request.files['video']

    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if not allowed_file(file.filename):
        return jsonify({'error': 'File type not allowed'}), 400

    # Generate unique ID
    video_id = str(uuid.uuid4())
    original_filename = secure_filename(file.filename)
    file_ext = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else 'mp4'

    # Save original file
    raw_path = os.path.join(RAW_VIDEO_FOLDER, f'{video_id}.{file_ext}')
    file.save(raw_path)

    # Get original duration and size
    duration, file_size = get_video_duration(raw_path)

    # Create video entry
    video_entry = {
        'id': video_id,
        'original_name': original_filename,
        'status': 'queued',
        'duration': duration,
        'original_size': file_size,
        'created_at': datetime.now().isoformat()
    }

    # Save video info
    import json
    info_file = os.path.join(UPLOAD_FOLDER, f'{video_id}_info.json')
    with open(info_file, 'w') as f:
        json.dump(video_entry, f)

    # Start transcoding in background
    output_path = os.path.join(PROCESSED_VIDEO_FOLDER, f'{video_id}.mp4')
    thread = threading.Thread(target=transcode_video, args=(raw_path, output_path, video_id))
    thread.start()

    return jsonify({
        'success': True,
        'video_id': video_id,
        'message': 'Video uploaded, processing started'
    })


@app.route('/api/videos')
def list_videos():
    """List all processed videos"""
    videos = []

    if os.path.exists(PROCESSED_VIDEO_FOLDER):
        for filename in os.listdir(PROCESSED_VIDEO_FOLDER):
            if filename.endswith('.mp4'):
                video_id = filename.replace('.mp4', '')
                video_path = os.path.join(PROCESSED_VIDEO_FOLDER, filename)
                file_size = os.path.getsize(video_path)
                duration, _ = get_video_duration(video_path)

                # Get original info
                info_file = os.path.join(UPLOAD_FOLDER, f'{video_id}_info.json')
                original_name = video_id
                if os.path.exists(info_file):
                    import json
                    with open(info_file, 'r') as f:
                        info = json.load(f)
                        original_name = info.get('original_name', video_id)

                # Get server URL from request
                server_url = request.host_url.rstrip('/')

                videos.append({
                    'id': video_id,
                    'name': original_name,
                    'url': f'{server_url}/stream/{filename}',
                    'size': file_size,
                    'duration': duration,
                    'status': 'ready'
                })

    return jsonify({'videos': videos})


@app.route('/api/video/<video_id>/status')
def get_video_status(video_id):
    """Get specific video processing status"""
    status = get_status(video_id)
    return jsonify({'video_id': video_id, 'status': status})


@app.route('/api/video/<video_id>', methods=['DELETE'])
def delete_video(video_id):
    """Delete a video"""
    try:
        # Delete original file
        for ext in ALLOWED_EXTENSIONS:
            raw_path = os.path.join(RAW_VIDEO_FOLDER, f'{video_id}.{ext}')
            if os.path.exists(raw_path):
                os.remove(raw_path)

        # Delete processed file
        processed_path = os.path.join(PROCESSED_VIDEO_FOLDER, f'{video_id}.mp4')
        if os.path.exists(processed_path):
            os.remove(processed_path)

        # Delete metadata files
        for suffix in ['_status.txt', '_info.json']:
            meta_file = os.path.join(UPLOAD_FOLDER, f'{video_id}{suffix}')
            if os.path.exists(meta_file):
                os.remove(meta_file)

        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/stream/<path:filename>')
def stream_video(filename):
    """Stream video with range request support"""
    video_path = os.path.join(PROCESSED_VIDEO_FOLDER, filename)

    if not os.path.exists(video_path):
        return "Video not found", 404

    # Handle range requests for video streaming
    range_header = request.headers.get('Range')
    file_size = os.path.getsize(video_path)

    if range_header:
        # Parse range header
        byte_start, byte_end = 0, file_size - 1
        range_match = range_header.replace('bytes=', '').split('-')
        if range_match[0]:
            byte_start = int(range_match[0])
        if len(range_match) > 1 and range_match[1]:
            byte_end = int(range_match[1])

        length = byte_end - byte_start + 1

        def generate():
            with open(video_path, 'rb') as f:
                f.seek(byte_start)
                remaining = length
                chunk_size = 1024 * 1024  # 1MB chunks
                while remaining > 0:
                    chunk = min(chunk_size, remaining)
                    data = f.read(chunk)
                    if not data:
                        break
                    remaining -= len(data)
                    yield data

        response = Response(generate(), status=206)
        response.headers['Content-Range'] = f'bytes {byte_start}-{byte_end}/{file_size}'
        response.headers['Accept-Ranges'] = 'bytes'
        response.headers['Content-Length'] = length
        response.headers['Content-Type'] = 'video/mp4'
    else:
        # Full file response
        response = Response(open(video_path, 'rb').read())
        response.headers['Content-Length'] = file_size
        response.headers['Content-Type'] = 'video/mp4'

    # CORS headers
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Range'
    response.headers['Access-Control-Expose-Headers'] = 'Content-Length, Content-Range'

    return response


if __name__ == '__main__':
    print("=" * 50)
    print("VRCHAT Video Stream Server")
    print("=" * 50)
    print("Starting server...")
    print()
    print("Web Interface: http://localhost:5000")
    print("Video Streaming: http://localhost:5000/stream/")
    print()
    print("=" * 50)
    app.run(host='0.0.0.0', port=5000, debug=False)